// Solo game: the platform still requires one code module at the archive root.
// Pure functions only, no imports, no timers.
export const meta = { game: "siste-buss", minPlayers: 1, maxPlayers: 1 };
export function setup() { return {}; }
export function validateAction() { return { ok: true }; }
export function applyAction(state) { return state; }
export function isGameOver() { return { over: false }; }
export function viewFor(state) { return state; }
